<?php

namespace App\Filament\Resources\StudentsResource\Widgets;

use Filament\Widgets\Widget;

class StudentCalendarWidget extends Widget
{
    protected static string $view = 'filament.resources.students-resource.widgets.student-calendar-widget';
}
