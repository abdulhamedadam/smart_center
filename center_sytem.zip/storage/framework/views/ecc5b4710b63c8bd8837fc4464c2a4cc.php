<div class="flex items-center space-x-2 mb-4" style="margin: auto">
    <button
        type="button"
        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'px-3 py-1 text-sm font-medium rounded-md',
    'bg-primary-500 text-white shadow-sm' => ($activeParent === null),
    'text-gray-700 hover:text-gray-900 hover:bg-gray-100' => ($activeParent !== null),
    ]); ?>"
    wire:click="setParentFilter(null)"
    >
    <?php echo e(__('common.all')); ?>

    </button>

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button
            type="button"
            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'px-3 py-1 text-sm font-medium rounded-md',
        'bg-primary-500 text-white shadow-sm' => ($activeParent == $parent->id),
        'text-gray-700 hover:text-gray-900 hover:bg-gray-100' => ($activeParent != $parent->id),
        ]); ?>"
        wire:click="setParentFilter(<?php echo e($parent->id); ?>)"
        >
        <?php echo e($parent->title); ?>

        </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp8.2\htdocs\My-Projects\center_sytem\resources\views/filament/resources/courses-resource/pages/materials-parent-tabs.blade.php ENDPATH**/ ?>