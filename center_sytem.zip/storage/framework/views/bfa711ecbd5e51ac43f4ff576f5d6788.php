<input
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
                'type' => 'hidden',
                $applyStateBindingModifiers('wire:model') => $getStatePath(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)
            ->class(['fi-fo-hidden'])); ?>

/>
<?php /**PATH C:\xampp8.2\htdocs\My-Projects\center_sytem\vendor\filament\forms\src\/../resources/views/components/hidden.blade.php ENDPATH**/ ?>