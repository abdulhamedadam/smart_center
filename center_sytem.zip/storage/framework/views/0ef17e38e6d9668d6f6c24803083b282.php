<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php echo $__env->make('filament.resources.students-resource.pages.details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if (isset($component)) { $__componentOriginal9b945b32438afb742355861768089b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b945b32438afb742355861768089b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="space-y-6" dir="rtl">
            <h3 class="text-lg font-medium"><?php echo e(__('Student Course Schedule')); ?></h3>

            <div class="overflow-x-auto">
                <!-- Calendar Grid -->
                <table class="min-w-full border border-gray-200 dark:border-gray-700 rounded-lg">
                    <!-- Months Header -->
                    <thead>
                    <tr>
                        <th class="w-24 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900"></th>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthName => $monthData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th colspan="<?php echo e(count($monthData['weeks'])); ?>"
                                class="text-center font-medium py-2 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                                <?php echo e('شهر - ' . $monthName); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>
                    </thead>

                    <!-- Weeks Header -->
                    <thead>
                    <tr>
                        <th class="w-24 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800"></th>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $monthData['weeks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="w-30 text-center py-1 text-sm border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
                                    <?php echo e($weekName); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>
                    </thead>

                    <!-- Days Rows -->
                    <tbody class="bg-white dark:bg-gray-800">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- Day Name Column -->
                            <td class="w-24 p-2 font-medium border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
                                <?php echo e($dayName); ?>

                            </td>

                            <!-- Week Columns -->
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->calendarData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekKey => $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $day = collect($week['days'])->firstWhere('dayName', $dayName);
                                    $isPast = $day && $day['date']->isPast() && !$day['date']->isToday();
                                    $isUpcoming = $day && $day['date']->isFuture() && $day['date']->diffInDays(now()) <= 7;
                                ?>

                                <td class="w-30 p-2 border border-gray-200 dark:border-gray-700
                                        <?php if($day && $day['date']->isToday()): ?> bg-primary-50 dark:bg-gray-600 <?php endif; ?>
                                <?php if($isPast): ?> is-past <?php endif; ?>
                                <?php if($isUpcoming): ?> is-upcomming <?php endif; ?>
                                <?php if(!$day): ?> bg-gray-50 dark:bg-gray-800 <?php endif; ?>"
                                    style="min-width: 120px; height: 120px">

                                    <!-- In your Blade template (updated schedule card display) -->
                                    <!--[if BLOCK]><![endif]--><?php if($day): ?>
                                        <div >
                                            <?php echo e($day['date']->format('Y-m-d')); ?>

                                        </div>

                                        <div >
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $day['schedules']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $attendance = $this->getAttendanceStatus(
                                                        $schedule->course_id,
                                                        $day['date']->format('Y-m-d'),
                                                        $this->record
                                                    );

                                                    $cardStyle = "";


                                                ?>

                                                <div style="<?php echo e($cardStyle); ?>">
                                                    <div style="font-weight: 500;"><?php echo e($schedule->course->name); ?></div>
                                                    <div><?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?></div>
                                                    <div style="color: #6b7280;"><?php echo e(@$schedule->instructor->name); ?></div>
                                                    <div style="font-size: 0.75rem; margin-top: 0.25rem;">
                                                        <!--[if BLOCK]><![endif]--><?php if($attendance['status'] == '1'): ?>
                                                            <span style="color: #16a34a;">● حاضر</span>
                                                        <?php elseif($attendance['status'] == '2'): ?>
                                                            <span style="color: #dc2626;">● غائب</span>
                                                        <?php elseif($attendance['status'] == '3'): ?>
                                                            <span style="color: #ca8a04;">● متأخر</span>
                                                        <?php else: ?>
                                                            <span style="color: #4b5563;">● لم يتم التسجيل</span>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b945b32438afb742355861768089b04)): ?>
<?php $attributes = $__attributesOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__attributesOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b945b32438afb742355861768089b04)): ?>
<?php $component = $__componentOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__componentOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\xampp8.2\htdocs\My-Projects\center_sytem\resources\views/filament/resources/students-resource/pages/schedules.blade.php ENDPATH**/ ?>