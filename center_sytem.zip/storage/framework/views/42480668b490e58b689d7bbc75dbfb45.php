<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp8.2\htdocs\My-Projects\center_sytem\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>