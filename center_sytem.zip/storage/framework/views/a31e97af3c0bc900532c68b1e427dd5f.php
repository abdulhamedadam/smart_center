<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp8.2\htdocs\My-Projects\center_sytem\resources\views/livewire/assignment_results_table.blade.php ENDPATH**/ ?>