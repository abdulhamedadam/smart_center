<x-filament-panels::page>

   @include('filament.resources.students-resource.pages.details')

</x-filament-panels::page>

